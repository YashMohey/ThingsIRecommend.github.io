/**
 * Provides classes for request/reply semantics.
 */
package org.springframework.kafka.requestreply;
