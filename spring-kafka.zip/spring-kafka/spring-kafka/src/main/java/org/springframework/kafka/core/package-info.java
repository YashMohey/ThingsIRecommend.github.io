/**
 * Package for kafka core components
 */
@org.springframework.lang.NonNullApi
package org.springframework.kafka.core;
