/**
 * Package for kafka annotations
 */
package org.springframework.kafka.annotation;
