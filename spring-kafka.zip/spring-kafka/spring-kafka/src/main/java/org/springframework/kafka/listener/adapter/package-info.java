/**
 * Provides classes for adapting listeners.
 */
package org.springframework.kafka.listener.adapter;
