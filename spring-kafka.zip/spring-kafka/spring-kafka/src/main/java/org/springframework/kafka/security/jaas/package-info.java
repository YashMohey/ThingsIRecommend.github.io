/**
 * Provides classes related to jaas.
 */
package org.springframework.kafka.security.jaas;
